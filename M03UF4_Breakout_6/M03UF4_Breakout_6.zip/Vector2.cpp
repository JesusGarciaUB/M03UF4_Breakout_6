#include "Vector2.h"

Vector2::Vector2()
{
}
